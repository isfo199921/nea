document.addEventListener('DOMContentLoaded', function() {
    
    const cartDrawer = document.getElementById('cart-drawer');
    const cartIcon = document.querySelector('a[href="/cart"]');
    // The drawer has a close button, let's handle it
    const initialCloseButton = cartDrawer.querySelector('button[is="close-button"]');
    const overlay = document.querySelector('.drawer__overlay');

    // Store the original empty state HTML to reuse it
    const originalCartDrawerContent = cartDrawer.innerHTML;

    function updateCartCount(count) {
        const cartCountElement = document.querySelector('a[href="/cart"] .count-bubble');
        if (cartCountElement) {
            if (count > 0) {
                cartCountElement.textContent = count;
                cartCountElement.classList.remove('opacity-0');
                cartCountElement.hidden = false;
            } else {
                cartCountElement.textContent = '0';
                cartCountElement.classList.add('opacity-0');
                cartCountElement.hidden = true;
            }
        }
    }

    function renderCartDrawer(data) {
        // Clear the drawer's current content
        cartDrawer.innerHTML = ''; 

        if (data.cart_count > 0) {
            // If the cart has items, build the HTML for them
            let itemsHTML = `<button is="close-button" aria-label="Close" style="position: absolute; top: 1rem; right: 1rem; z-index: 1;"><svg role="presentation" stroke-width="2" focusable="false" width="24" height="24" class="icon icon-close" viewBox="0 0 24 24"><path d="M17.658 6.343 6.344 17.657M17.658 17.657 6.344 6.343" stroke="currentColor"></path></svg></button>`;
            itemsHTML += `<div class="prose" style="padding: 1.5rem 2rem; border-bottom: 1px solid #eee;"><h2 class="h4" style="margin:0;">Cart (${data.cart_count})</h2></div>`;
            
            for (const id in data.items) {
                const item = data.items[id];
                itemsHTML += `
                    <div style="display: flex; align-items: center; padding: 1.5rem 2rem; border-bottom: 1px solid #eee; gap: 1rem;">
                        <img src="${item.image}" alt="${item.name}" style="width: 70px; height: 90px; object-fit: cover; border-radius: 8px;">
                        <div style="flex-grow: 1;">
                            <p style="margin: 0; font-weight: 600; font-size: 0.9rem;">${item.name}</p>
                            <div class="quantity-selector" style="margin-top: 0.5rem;">
                                <button class="quantity-btn" data-id="${id}" data-action="decrease">-</button>
                                <span>${item.quantity}</span>
                                <button class="quantity-btn" data-id="${id}" data-action="increase">+</button>
                            </div>
                        </div>
                        <p style="margin: 0; font-weight: 600; font-size: 1rem;">$${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                `;
            }
            
            if (data.recommendations && data.recommendations.length > 0) {
                itemsHTML += `<div style="padding: 1.5rem 2rem; border-bottom: 1px solid #eee;">
                                <h3 style="margin-top:0; margin-bottom: 1rem; font-size: 1rem;">Bundle & Save:</h3>`;
                data.recommendations.forEach(rec => {
                    itemsHTML += `
                        <div class="recommendation-card" style="margin-bottom: 1rem;">
                            <img src="${rec.image}" alt="${rec.name}" style="width: 50px; height: 65px; object-fit: cover; border-radius: 4px;">
                            <div style="flex-grow: 1;">
                                <p style="margin: 0; font-size: 0.85rem;">${rec.name}</p>
                                <p style="margin: 0.2rem 0; font-size: 0.85rem; color: #666;">$${rec.price.toFixed(2)}</p>
                            </div>
                            <form class="recommendation-form" method="post" action="/cart/add">
                                <input type="hidden" name="id" value="${rec.id}">
                                <button type="submit" class="button">+ Add</button>
                            </form>
                        </div>
                    `;
                });
                itemsHTML += '</div>';
            }

            itemsHTML += `
                <div style="padding: 1.5rem 2rem; text-align: right; font-size: 1.25rem; font-weight: bold;">
                    Total: $${data.subtotal.toFixed(2)} USD
                </div>
                <div style="padding: 0 2rem 2rem;">
                    <a href="/checkout" class="button button--xl" style="width: 100%; text-align: center; display: block; background-color: #71d1d0; color: black;">Checkout</a>
                </div>
            `;
            cartDrawer.innerHTML = itemsHTML;
        } else {
             // If cart is empty, restore the original content which includes the "empty" message
             cartDrawer.innerHTML = originalCartDrawerContent;
        }
        
        // Re-attach close listeners since we overwrote the innerHTML
        cartDrawer.querySelectorAll('button[is="close-button"]').forEach(button => {
            button.addEventListener('click', e => {
                e.preventDefault();
                closeCartDrawer();
            });
        });
    }

    function openCartDrawer() {
        cartDrawer.classList.add('is-open');
        overlay.style.visibility = 'visible';
        overlay.style.opacity = '1';
    }

    function closeCartDrawer() {
        cartDrawer.classList.remove('is-open');
        overlay.style.visibility = 'hidden';
        overlay.style.opacity = '0';
    }

    function handleCartAction(url, options) {
        fetch(url, options).then(res => res.json()).then(data => {
            if (data.success) {
                updateCartCount(data.cart_count);
                renderCartDrawer(data);
            }
        }).catch(error => console.error('Error:', error));
    }

    // --- Event Listeners ---
    cartIcon.addEventListener('click', e => { 
        e.preventDefault(); 
        fetch('/cart/data').then(res => res.json()).then(data => {
            renderCartDrawer(data);
            openCartDrawer();
        });
    });

    if (initialCloseButton) {
        initialCloseButton.addEventListener('click', e => {
            e.preventDefault();
            closeCartDrawer();
        });
    }
    
    overlay.addEventListener('click', closeCartDrawer);

    // Fetch initial cart count on page load
    fetch('/cart/data').then(res => res.json()).then(data => updateCartCount(data.cart_count));

    // Handle form submissions for adding items
    document.body.addEventListener('submit', function(event) {
        const form = event.target;
        if (form.matches('form[action="/cart/add"]')) {
            event.preventDefault();
            const formData = new FormData(form);
            const button = form.querySelector('button[type="submit"]');
            if(button) button.classList.add('is-loading');
            
            fetch('/cart/add', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        updateCartCount(data.cart_count);
                        renderCartDrawer(data); // Render the new content
                        openCartDrawer(); // Then open the drawer
                    }
                })
                .catch(error => console.error('Error:', error))
                .finally(() => { if(button) button.classList.remove('is-loading'); });
        }
    });

    // Handle quantity changes and remove
    cartDrawer.addEventListener('click', function(event) {
        const target = event.target;
        if (target.matches('.quantity-btn')) {
            const id = target.dataset.id;
            const action = target.dataset.action;
            handleCartAction(`/cart/update/${id}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: action })
            });
        }
    });
});
